<div class='container_wrap footer_color' id='footer'>

				<center>
					<p style="color: white;font-size: 25px;">Sizal HD Lenses</p>
				</center>

				<div class='container'>

					<div class='flex_column av_one_third  first el_before_av_one_third'  style="width: 27%;">
						<section id="nav_menu-5" class="widget clearfix widget_nav_menu">
							<h3 class="widgettitle">I Wear Spectacle</h3>
							<div class="menu-i-wear-spectacles-container">
								<ul id="menu-i-wear-spectacles" class="menu">
									<li id="menu-item-1305"
										class="menu-item menu-item-type-custom menu-item-object-custom current-menu-item menu-item-1305"><a
											href="index.php" aria-current="page">Keep Me Informed</a></li>
								</ul>
							</div><span class="seperator extralight-border"></span>
						</section>
					</div>
					<div class='flex_column av_one_third  el_after_av_one_third  el_before_av_one_third ' style="margin-left:4%;width: 27%;">
						<section id="nav_menu-7" class="widget clearfix widget_nav_menu">
							<h3 class="widgettitle">I Am In Eyecare Business</h3>
							<div class="menu-i-am-in-eye-care-business-container">
								<ul id="menu-i-am-in-eye-care-business" class="menu">
									<li id="menu-item-1302"
										class="menu-item menu-item-type-custom menu-item-object-custom current-menu-item menu-item-1302"><a
											href="index.php" aria-current="page">&#8211; Want to partner your business</a></li>
									<li id="menu-item-1303"
										class="menu-item menu-item-type-custom menu-item-object-custom current-menu-item menu-item-1303"><a
											href="index.php" aria-current="page">&#8211; Like to be contacted</a></li>
									<li id="menu-item-1304"
										class="menu-item menu-item-type-custom menu-item-object-custom current-menu-item menu-item-1304"><a
											href="index.php" aria-current="page">&#8211; Interested in receiving product information</a></li>
								</ul>
							</div><span class="seperator extralight-border"></span>
						</section>
					</div>
					<div class='flex_column av_one_third  el_after_av_one_third  el_before_av_one_third ' style="margin-left:4%;width: 27%;">
						<section id="nav_menu-9" class="widget clearfix widget_nav_menu">
							<div class="menu-contact-footer-container">
								<ul id="menu-contact-footer" class="menu">
									<li id="menu-item-2176"
										class="menu-item menu-item-type-post_type menu-item-object-page current-menu-item page_item page-item-2116 current_page_item menu-item-2176">
										<a href="contact-us.php" aria-current="page">CONTACT US</a></li>
										<!--<a href="contact-us.php" aria-current="page">CONTACT US</a></li>-->
									<li id="menu-item-2898"
										class="menu-item menu-item-type-post_type menu-item-object-page menu-item-2898"><a
											href="aboutus.php">About Us</a></li>
									<li id="menu-item-2898"
										class="menu-item menu-item-type-post_type menu-item-object-page menu-item-2898"><a
											href="privicy-policy.php">Privacy & Policy</a></li>
									<li id="menu-item-2898"
										class="menu-item menu-item-type-post_type menu-item-object-page menu-item-2898"><a
											href="terms-condition.php">Terms & Condition</a></li>
								</ul>
							</div><span class="seperator extralight-border"></span>
						</section>
					</div>
                    <div class='flex_column av_one_third  el_after_av_one_third  el_before_av_one_third ' style="margin-left:2%; width: 20%; position:absolute;right:0;">
						<section id="nav_menu-10" class="widget clearfix widget_nav_menu">
							<div class="menu-contact-footer-container">
								<ul id="menu-contact-foote" class="menu">
									<li id="menu-item-2176"
										class="menu-item menu-item-type-post_type menu-item-object-page current-menu-item page_item page-item-2116 current_page_item menu-item-2176">
										<a href="https://play.google.com/store/apps/details?id=com.techcherry.SIZALHDLENSES&hl=en" aria-current="page"> 
											<img src="wp-content/uploads/2022image/glogo.png" style="border-radius: 4px; width:150px ;height:auto;">
										</a></li>
									
									<li id="menu-item-2898"
										class="menu-item menu-item-type-post_type menu-item-object-page menu-item-2898">Download Sizal HD Lenses <br>App to buy Lenses</li>
								</ul>
							</div><span class="seperator extralight-border"></span>
						</section>
					</div>
				</div>


				<!-- ####### END FOOTER CONTAINER ####### -->
			</div>
			
			
			<footer class='container_wrap socket_color' id='socket' role="contentinfo" itemscope="itemscope"
				itemtype="https://schema.org/WPFooter">
				<div class='container'>

					<span class='copyright'>&copy; Copyright - <a href='index.html'>Sizal HD Lenses</a></span>

					<ul class='noLightbox social_bookmarks icon_count_5'>
						<li class='social_bookmarks_facebook av-social-link-facebook social_icon_1'><a target="_blank"
								aria-label="Link to Facebook" href='https://m.facebook.com/SIZALHDLENSES/?_rdr' aria-hidden='false'
								data-av_icon='' data-av_iconfont='entypo-fontello' title='Facebook' rel="noopener"><span
									class='avia_hidden_link_text'>Facebook</span></a></li>
						<li class='social_bookmarks_twitter av-social-link-twitter social_icon_2'><a target="_blank"
								aria-label="Link to Twitter" href='#' aria-hidden='false' data-av_icon=''
								data-av_iconfont='entypo-fontello' title='Twitter' rel="noopener"><span
									class='avia_hidden_link_text'>Twitter</span></a></li>
						<li class='social_bookmarks_instagram av-social-link-instagram social_icon_3'><a target="_blank"
								aria-label="Link to Instagram" href='https://www.instagram.com/sizal_hd_lenses/?utm_source=qr' aria-hidden='false'
								data-av_icon='' data-av_iconfont='entypo-fontello' title='Instagram' rel="noopener"><span
									class='avia_hidden_link_text'>Instagram</span></a></li>
						<li class='social_bookmarks_pinterest av-social-link-pinterest social_icon_4'><a target="_blank"
								aria-label="Link to Pinterest" href='#' aria-hidden='false'
								data-av_icon='' data-av_iconfont='entypo-fontello' title='Pinterest' rel="noopener"><span
									class='avia_hidden_link_text'>Pinterest</span></a></li>
						<li class='social_bookmarks_youtube av-social-link-youtube social_icon_5'><a target="_blank"
								aria-label="Link to Youtube" href='#'
								aria-hidden='false' data-av_icon='' data-av_iconfont='entypo-fontello' title='Youtube'
								rel="noopener"><span class='avia_hidden_link_text'>Youtube</span></a></li>
					</ul>
					<nav class='sub_menu_socket' role="navigation" itemscope="itemscope"
						itemtype="https://schema.org/SiteNavigationElement">
						<div class="avia3-menu">
							<ul id="avia3-menu" class="menu">
								<li id="menu-item-2896"
									class="menu-item menu-item-type-post_type menu-item-object-page menu-item-top-level menu-item-top-level-1">
									<a href="index.php" itemprop="url"><span class="avia-bullet"></span><span
											class="avia-menu-text">Blog</span><span class="avia-menu-fx"><span class="avia-arrow-wrap"><span
													class="avia-arrow"></span></span></span></a></li>
							</ul>
						</div>
					</nav>
				</div>

				<!-- ####### END SOCKET CONTAINER ####### -->
			</footer>